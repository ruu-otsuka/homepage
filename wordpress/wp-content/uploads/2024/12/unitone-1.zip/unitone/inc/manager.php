<?php
/**
 * @package unitone
 * @author inc2734
 * @license GPL-2.0+
 */

new Unitone\App\Controller\Manager\Manager();
