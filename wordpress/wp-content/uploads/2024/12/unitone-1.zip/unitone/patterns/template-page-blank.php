<?php
/**
 * Title: Pages: Blank
 * Slug: unitone/template/page/blank
 * Categories: unitone-templates
 * Template Types: page, wp-custom-template
 * Inserter: no
 */
?>
<!-- wp:post-content {"layout":{"type":"constrained"}} /-->
