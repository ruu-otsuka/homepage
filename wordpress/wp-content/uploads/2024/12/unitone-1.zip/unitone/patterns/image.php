<?php
/**
 * Title: Image
 * Slug: unitone/image
 * inserter: false
 */
?>
<!-- wp:image {"id":1,"width":1920,"height":1280,"lock":{"remove":true,"move":true}} -->
<figure class="wp-block-image is-resized">
	<img src="<?php echo esc_url( get_template_directory_uri() ); ?>/dist/img/stocksnap_lgg8nat9jy.jpg" alt="" class="wp-image-1"/>
</figure>
<!-- /wp:image -->
